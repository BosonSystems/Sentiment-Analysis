<?php

View::composer('site/blog/view_post', 'Acme\Composers\CommentComposer');
