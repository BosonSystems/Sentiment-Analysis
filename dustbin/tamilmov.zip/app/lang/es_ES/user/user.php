<?php 

return array(

	/*
	|--------------------------------------------------------------------------
	| User Language Lines
	|--------------------------------------------------------------------------
	|
	|
	*/

	'register'              => 'Registrar',
	'login'                 => 'Iniciar sesión',
	'login_first'           => 'Iniciar sesión primero',
	'account'               => 'Cuenta',
	'forgot_password'       => '¿ Olvidaste tu contraseña ?',
	'settings'              => 'Configuración',
	'profile'               => 'Perfil',
	'user_account_is_not_confirmed'          => 'La cuenta de usuario no está confirmada.',
	'user_account_updated'          => 'Cuenta de usuario actualizada.',
	'user_account_created'          => 'Cuenta de usuario creada.',

);