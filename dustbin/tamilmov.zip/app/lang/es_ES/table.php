<?php

return array(

	'actions' => 'Acciones'

);
