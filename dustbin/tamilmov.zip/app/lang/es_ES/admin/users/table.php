<?php

return array(

	'first_name' => 'Nombre',
	'last_name'  => 'Apellido',
	'user_id'  => 'Id de usuario',
	'username'  => 'Usuario',
	'email'      => 'Email',
	'groups'     => 'Grupos',
	'roles'     => 'Roles',
	'activated'  => 'Activado',
	'created_at' => 'Creado el',

);
