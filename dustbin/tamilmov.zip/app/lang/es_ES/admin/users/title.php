<?php

return array(

	'user_management'    => 'Administración de usuarios',
	'user_update'        => 'Modificar usuario',
	'user_delete'        => 'Borrar usuario',
	'create_a_new_user'  => 'Crear nuevo usuario',

);
