<?php

return array(

	'blog_management'    => 'Administrar el Blog',
	'blog_update'        => 'Actualizar un Blog',
	'blog_delete'        => 'Borrar un Blog',
	'create_a_new_blog'  => 'Crear un nuevo Blog',

);