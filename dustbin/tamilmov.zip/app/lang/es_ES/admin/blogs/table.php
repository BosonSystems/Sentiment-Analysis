<?php

return array(

	'title'      => 'Título del blog',
	'comments'   => '# de Comentarios',
	'created_at' => 'Creado el',
	'post_id' => 'Id del Post',

);
