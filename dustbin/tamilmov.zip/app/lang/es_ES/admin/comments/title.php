<?php

return array(

	'comment_management'    => 'Administrar los Comentarios del Blog',
	'comment_update'        => 'Actualizar un Comentario',
	'comment_delete'        => 'Borrar un Comentario',
	'create_a_new_comment'  => 'Crear un nuevo Comentario',

);