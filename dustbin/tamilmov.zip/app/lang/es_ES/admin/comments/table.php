<?php

return array(

	'title'      => 'Comentario',
	'user_id'   => '# de Comentarios',
	'created_at' => 'Creado el',

);
