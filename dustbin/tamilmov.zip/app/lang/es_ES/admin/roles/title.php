<?php

return array(

	'role_management'    => 'Administrar Roles',
	'role_update'        => 'Modificar Roles',
	'role_delete'        => 'Borrar Roles',
	'create_a_new_role'  => 'Crear un nuevo Rol',

);