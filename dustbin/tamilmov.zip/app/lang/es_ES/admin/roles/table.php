<?php

return array(

	'name'       => 'Nombre',
	'users'      => '# de Usuarios',
	'created_at' => 'Creado el',

);
