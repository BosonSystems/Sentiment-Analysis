<?php

return array(

	'yes' => 'Si',
	'no'  => 'No',
    'must_login' => 'Es necesario iniciar sesión'

);
