<?php

return array(

	'edit'   => 'Editar',
	'delete' => 'Borrar'
);
