<?php

return array(

	'yes' => 'Sim',
	'no'  => 'N&atilde;o',
    'must_login' => 'Deve estar conectado.'

);
