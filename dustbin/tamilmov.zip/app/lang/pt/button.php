<?php

return array(

	'edit'   => 'Editar',
	'delete' => 'Apagar'
);
