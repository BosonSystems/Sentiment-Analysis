You don't have the correct permissions to add comments.
